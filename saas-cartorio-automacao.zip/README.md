# SaaS Cartório de Automação

Sistema completo para automação do atendimento de títulos em cartórios via WhatsApp ou plataforma web.

## Funcionalidades
- Submissão de títulos com responsabilidade do apresentante
- Integração CRA/CENPROT com geração de anuência
- Filas com Redis para processamento assíncrono
- Backend com NestJS + Prisma + PostgreSQL
- Frontend com Next.js + Tailwind + shadcn/ui

## Tecnologias
- NestJS + BullMQ + Prisma
- PostgreSQL
- Next.js + Tailwind
- Docker + docker-compose

## Rodando Localmente
```bash
git clone <repo-url>
cd saas-cartorio-automacao
docker-compose up --build
```

## Deploy
Pronto para Railway, Render, Fly.io ou Vercel com configurações mínimas.
